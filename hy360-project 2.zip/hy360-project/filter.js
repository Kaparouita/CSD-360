function filterVehicles() {
    var selectedType = document.getElementById('vehicleTypeFilter').value;
    var vehicles = document.querySelectorAll('.vehicle-item');

    vehicles.forEach(function(vehicle) {
        var vehicleType = vehicle.getAttribute('data-type');
        var vehiclePrice = vehicle.getAttribute('data-price'); // Get the data-price attribute
        var priceElement = vehicle.querySelector('.vehicle-price'); // Get the price placeholder element

        if (selectedType === 'all' || selectedType === vehicleType) {
            vehicle.style.display = 'block';
            // Display the price if available
            if (priceElement && vehiclePrice) {
                priceElement.textContent = 'Price per day: $' + vehiclePrice;
            }
        } else {
            vehicle.style.display = 'none';
            // Clear the price if not matching the filter
            if (priceElement) {
                priceElement.textContent = '';
            }
        }
    });
}

document.getElementById('rentButton').addEventListener('click', function () {
    var vehicleName= document.querySelectorAll('.vehicle-item');
    var vehiclePrice = vehicle.getAttribute('data-price'); // Get the data-price attribute
    var priceElement = vehicle.querySelector('.vehicle-price'); // Get the price placeholder element
    var vehicledata = vehicle.querySelector('.vehicle-data');

    // Δημιουργήστε την URL για τη νέα σελίδα με τα παραμετροποιημένα δεδομένα
    var newPageUrl = "rental-page.html?" +
        "vehicleName=" + encodeURIComponent(vehicleName) +
        "&Price=" + encodeURIComponent(vehiclePrice);
    // Πηγαίνετε στη νέα σελίδα
    window.location.href = newPageUrl;
});
