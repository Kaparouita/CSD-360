
    document.getElementById('vehicle-type').addEventListener('change', function() {
        var showLicense = this.value === 'car' || this.value === 'motorcycle';
        document.getElementById('license-section').style.display = showLicense ? 'block' : 'none';
    });

    const insuranceCostPerDay = 10; 
    const pricePerDay=70;

function updateCost() {
    const rentalDays = parseInt(document.getElementById('rental-days').value);
    let totalCost = rentalDays * pricePerDay; // Βασικό κόστος ενοικίασης

    // Προσθήκη κόστους ασφάλισης αν είναι επιλεγμένο
    if (document.getElementById('insurance').checked) {
        totalCost += rentalDays * insuranceCostPerDay;
    }

    document.getElementById('total-cost').textContent = 'Συνολικό Κόστος: ' + totalCost + '€';
}


updateCost();

   
