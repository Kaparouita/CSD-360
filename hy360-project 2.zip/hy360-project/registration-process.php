<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Δημιουργία σύνδεσης με τη βάση δεδομένων
    $conn = new mysqli("hostname", "username", "password", "database");

    // Έλεγχος σύνδεσης
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Λήψη και καθαρισμός των δεδομένων της φόρμας
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $license_number = mysqli_real_escape_string($conn, $_POST['license_number']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $date_of_birth = mysqli_real_escape_string($conn, $_POST['date_of_birth']);
   

    // Κωδικοποίηση του κωδικού πρόσβασης
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Δημιουργία και εκτέλεση του SQL ερωτήματος
    $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";
    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    if ($registrationSuccessful) { // Replace $registrationSuccessful with your actual condition
        header('Location: home.html'); // Redirect to the home page
        exit(); // Ensure no further code is executed
    }

    // Κλείσιμο της σύνδεσης
    $conn->close();
}
?>
